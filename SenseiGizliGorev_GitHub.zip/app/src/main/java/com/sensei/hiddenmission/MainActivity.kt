package com.sensei.hiddenmission

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        home()
    }

    private fun layout(): LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL
        gravity=Gravity.CENTER_HORIZONTAL
        setPadding(28,35,28,25)
        setBackgroundColor(Color.rgb(8,11,20))
    }

    private fun txt(s:String, size:Float=18f)=TextView(this).apply {
        text=s; textSize=size; setTextColor(Color.WHITE); gravity=Gravity.CENTER
        setPadding(8,12,8,12)
    }

    private fun btn(s:String, f:()->Unit)=Button(this).apply {
        text=s; textSize=16f; setOnClickListener{f()}
    }

    private fun home() {
        root=layout()
        root.addView(txt("🥷 SENSEI",38f))
        root.addView(txt("GİZLİ GÖREV",27f))
        root.addView(txt("4–10 kişilik sosyal çıkarım oyunu\nGörevini tamamla ve sabotajcıyı bul!",17f))
        root.addView(btn("🎮 Oda Oluştur"){createRoom()})
        root.addView(btn("🚪 Odaya Katıl"){joinRoom()})
        root.addView(btn("ℹ️ Nasıl Oynanır"){
            AlertDialog.Builder(this).setTitle("Nasıl oynanır?")
                .setMessage("Oyuncular görevlerini tamamlar. Sabotajcı gizlice ekibi bozmaya çalışır. Toplantıda konuşup oylama yapın. Takımın veya sabotajcının hedefi tamamlanınca oyun biter.")
                .setPositiveButton("Tamam",null).show()
        })
        setContentView(root)
    }

    private fun createRoom() {
        val code=(100000..999999).random().toString()
        lobby(code,true)
    }

    private fun joinRoom() {
        val input=EditText(this).apply { hint="6 haneli oda kodu"; inputType=2 }
        AlertDialog.Builder(this).setTitle("Odaya Katıl").setView(input)
            .setPositiveButton("Katıl"){_,_->lobby(input.text.toString(),false)}
            .setNegativeButton("İptal",null).show()
    }

    private fun lobby(code:String,host:Boolean) {
        root=layout()
        root.addView(txt("🏯 ODA LOBİSİ",28f))
        root.addView(txt("Oda Kodu\n$code",24f))
        root.addView(txt(if(host)"Sen odanın sahibisin." else "Odaya bağlanıldı (demo)."))
        root.addView(txt("👤 Oyuncular: 1 / 10"))
        root.addView(btn("▶️ Oyunu Başlat"){game()})
        root.addView(btn("← Ana Menü"){home()})
        setContentView(root)
    }

    private fun game() {
        root=layout()
        root.addView(txt("🥷 SENSEI: GİZLİ GÖREV",25f))
        root.addView(txt("📍 Görev Merkezi"))
        root.addView(txt("Görevler: 1 / 3"))
        root.addView(btn("🔧 Kablo Panelini Onar"){toast("Görev tamamlandı!")})
        root.addView(btn("⚡ Enerji Çekirdeğini Kontrol Et"){toast("Görev tamamlandı!")})
        root.addView(btn("📡 Sinyal Sistemini Çalıştır"){toast("Görev tamamlandı!")})
        root.addView(btn("🚨 ACİL TOPLANTI"){meeting()})
        root.addView(btn("☠️ Oyundan Çık"){home()})
        setContentView(root)
    }

    private fun meeting() {
        val names=arrayOf("Sensei_01","Sensei_02","Sensei_03","Sensei_04")
        val checked=BooleanArray(names.size)
        AlertDialog.Builder(this).setTitle("🚨 Acil Toplantı")
            .setSingleChoiceItems(names,-1){d,which->
                toast("${names[which]} için oy verdin")
                d.dismiss()
            }.setNegativeButton("Toplantıyı Kapat",null).show()
    }

    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
